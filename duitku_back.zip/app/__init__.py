"""DuitKu Backend application package."""

