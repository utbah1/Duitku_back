"""Core configuration and infrastructure."""

